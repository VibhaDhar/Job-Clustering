package com.project;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QualificationUtils {
	public static int MASTERS = 10, BACHELORS = 5, COLLEGE_DEGREE = 3, HIGH_SCHOOL = 2, OTHERS = 1;
	public static List<String> bachelorsDegrees = Arrays.asList("bachelor", "bachelors", "bachelor's","Bachelors", "Bachelor", "BS", "B.S", "B.S.", "Bachelor's", "BA");
	public static List<String> mastersDegrees = Arrays.asList("master", "masters", "master's","Masters","Master","MS", "M.S", "M.S.", "Master's","MBA" ); 
	public static List<String> highSchoolDegrees = Arrays.asList("High School Diploma", "High School");
	public static List<String> collegeDegrees = Arrays.asList("College Degrgee", "Associate's","AA", "AS");
	
			
	public static int getQualificationWeightage(String str)	{
		int weightage = 0;
		if(str != null) {
			if(mastersDegrees.contains(str)) {
				weightage = MASTERS;
			} else if(bachelorsDegrees.contains(str)) {
				weightage = BACHELORS;
			} else if(collegeDegrees.contains(str)) {
				weightage = COLLEGE_DEGREE;
			} else if(highSchoolDegrees.contains(str)) {
				weightage = HIGH_SCHOOL;
			} else {
				weightage = OTHERS;
			}
		}
		return weightage;
	}
	
	public static String getQualification(String str)	{
		String qualification = null;
		if(str != null) {
			Matcher m = qualificationPattern.matcher(str);
			if(m.find()) {	
				qualification = m.group();
			}
		}
		return qualification;
	}
	
	public static Pattern qualificationPattern = Pattern.compile(
			 "|Bachelor(s*)|B(\\.*)S(\\.*)|(B|b)achelor('*)(s*)|BS[a-zA-Z]+"
			+ "MS[a-zA-Z]|M(\\.*)S(\\.*)|(M|m)aster('*)(s*)+"
			+ "|AA|AS|(C|c)ollege (D|d)egree|MBA|BA|High School Diploma|High School|Associate's");
	

}
