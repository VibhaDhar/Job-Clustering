package com.project.bean;


public class JobFeatures {
	public String City;
	public String State;
	public String Experience;
	public String Qualification;
	public String Role;
}
