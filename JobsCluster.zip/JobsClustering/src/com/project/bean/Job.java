package com.project.bean;


public class Job {
	public String JobID;
	public String Description;
	public String Requirements;
	public String City;
	public String State;
	public int Experience;
	public String Qualification;
	public int QualificationWeightage;
	public String Role;
	public int StateWeightage;
	public int clusterId;
}
