package com.project;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TestRegEx {
	public static void main(String[] args) {
		//String str = "two to four years of related experience";
		String str = "For 50 years, Aflac p";
		/*Pattern pattern = Pattern.compile("[0-9]+ (Y|y)ear(s)* (as|of|in)*( )*(?!age).?");
		Matcher matcher = pattern.matcher(str);
		if(matcher.find()) {
			int start = matcher.start();
			int end = matcher.end();
			String str1 = str.substring(start,end);
			System.out.println("Matched : " + str1);
		}*/
		System.out.println("Exp : " + ExperienceUtils.getExperience(str));
	}
}
